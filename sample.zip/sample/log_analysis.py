import csv

def parse_log_file(file_path):
    """Parse the log file and return lines as a list."""
    with open(file_path, 'r') as file:
        return file.readlines()

def count_requests_per_ip(log_lines):
    """Count the number of requests made by each IP address."""
    request_counts = {}
    for line in log_lines:
        ip = line.split()[0]  # Extract the IP address (first part of the line)
        request_counts[ip] = request_counts.get(ip, 0) + 1
    return request_counts

def find_most_accessed_endpoint(log_lines):
    """Identify the most frequently accessed endpoint."""
    endpoint_counts = {}
    for line in log_lines:
        parts = line.split('"')
        if len(parts) > 1:
            request = parts[1]  # Extract the HTTP request
            endpoint = request.split()[1]  # Extract the endpoint (second part of the request)
            endpoint_counts[endpoint] = endpoint_counts.get(endpoint, 0) + 1
    if endpoint_counts:
        return max(endpoint_counts.items(), key=lambda x: x[1])  # Return the endpoint with max accesses
    return None, 0

def detect_suspicious_activity(log_lines, threshold=10):
    """Detect suspicious activity based on failed login attempts."""
    failed_attempts = {}
    for line in log_lines:
        if "401" in line and "Invalid credentials" in line:
            ip = line.split()[0]  # Extract the IP address
            failed_attempts[ip] = failed_attempts.get(ip, 0) + 1
    # Filter IPs exceeding the threshold
    flagged_ips = {ip: count for ip, count in failed_attempts.items() if count > threshold}
    return flagged_ips

def save_results_to_csv(request_counts, most_accessed_endpoint, suspicious_activity):
    """Save the analysis results to a CSV file."""
    with open('log_analysis_results.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # Write requests per IP
        writer.writerow(["IP Address", "Request Count"])
        for ip, count in sorted(request_counts.items(), key=lambda x: x[1], reverse=True):
            writer.writerow([ip, count])
        
        # Write most accessed endpoint
        writer.writerow([])
        writer.writerow(["Most Accessed Endpoint", "Access Count"])
        writer.writerow([most_accessed_endpoint[0], most_accessed_endpoint[1]])
        
        # Write suspicious activity
        writer.writerow([])
        writer.writerow(["IP Address", "Failed Login Count"])
        for ip, count in suspicious_activity.items():
            writer.writerow([ip, count])

def main():
    log_file_path = "sample.log"  # Replace with the path to your log file
    log_lines = parse_log_file(log_file_path)
    
    # Count requests per IP
    request_counts = count_requests_per_ip(log_lines)
    print("IP Address           Request Count")
    for ip, count in sorted(request_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"{ip:<20} {count}")
    
    # Find the most frequently accessed endpoint
    most_accessed_endpoint = find_most_accessed_endpoint(log_lines)
    print("\nMost Frequently Accessed Endpoint:")
    print(f"{most_accessed_endpoint[0]} (Accessed {most_accessed_endpoint[1]} times)")
    
    # Detect suspicious activity
    suspicious_activity = detect_suspicious_activity(log_lines)
    print("\nSuspicious Activity Detected:")
    if suspicious_activity:
        print("IP Address           Failed Login Attempts")
        for ip, count in suspicious_activity.items():
            print(f"{ip:<20} {count}")
    else:
        print("No suspicious activity detected.")
    
    # Save results to CSV
    save_results_to_csv(request_counts, most_accessed_endpoint, suspicious_activity)
    print("\nResults saved to log_analysis_results.csv")

if __name__ == "__main__":
    main()
